from django.shortcuts import render
from pymongo import MongoClient
#from models import Database

def home(request):
  return render(request,"index.html")


def addbook(request):
    return render(request,"result.html")


def books(request):
    msg=None
    if request.method=="POST":
        try:  
             id=request.POST.get("id")
             ti=request.POST.get("title")
             auth=request.POST.get("author")
             gen=request.POST.get("genre")
             py=request.POST.get("published_year")
             ib=request.POST.get("isbn")
             pg=request.POST.get("pages")
             la=request.POST.get("language")
             pb=request.POST.get("publisher")

             dic={}
             dic['id']=id
             dic["title"]=ti
             dic["author"]=auth
             dic["genre"]=gen
             dic["published_year"]=py
             dic["isbn"]=ib
             dic["pages"]=pg
             dic["language"]=la
             dic["publisher"]=pb
             
             client=MongoClient("mongodb+srv://nawalkarvaishnavi12:vaishnavi3105@vaishnavicluster.b3hvcgi.mongodb.net/?retryWrites=true&w=majority&appName=VaishnaviCluster")
             db=client["vaishnavidb"]
             coll = db['Book']
             print(dic)
             
             coll.insert_one(dic)
             msg="Book Added Successfully"
        except:
             msg="Error in Insert"  
   

        dic={}
        dic['status']=msg   

        return render(request,"addstatus.html",dic)
    

def search(request):
   if request.method=="POST":
      fid=request.POST.get("book")
      dic={}
      dic["id"]=fid
      print(dic)
      client=MongoClient("mongodb+srv://nawalkarvaishnavi12:vaishnavi3105@vaishnavicluster.b3hvcgi.mongodb.net/?retryWrites=true&w=majority&appName=VaishnaviCluster")
      db=client['vaishnavidb']
      collection = db['Book']
      for s in collection.find(dic):
       print(s)
   return render(request,"search.html",s)

def devil(request):
   client=MongoClient("mongodb+srv://nawalkarvaishnavi12:vaishnavi3105@vaishnavicluster.b3hvcgi.mongodb.net/?retryWrites=true&w=majority&appName=VaishnaviCluster")

   db=client["vaishnavidb"]
   collection = db["Book"]
   k={}
   for k in collection.find():
    print(k)



   return render(request,"searchbook.html",{'Book':k})

def lala(request):
   return render(request,"UpdateBook.html")


    

def mini(request):
   su=None
   if request.method=="POST":
      try:
         id=request.POST.get('_id')
         ti=request.POST.get("title")
         au=request.POST.get("author")
         pa=request.POST.get("pages")
         la=request.POST.get("language")

         n={}
         n['_id']=id
         ch={}
         ch['title']=ti
         ch['author']=au
         ch['pages']=pa
         ch['language']=la
         upd={'$set':ch}
         client=MongoClient("mongodb+srv://nawalkarvaishnavi12:vaishnavi3105@vaishnavicluster.b3hvcgi.mongodb.net/?retryWrites=true&w=majority&appName=VaishnaviCluster")
         db=client['vaishnavidb']
         coll = db["Book"]
         coll.update_one(n,upd)
         print("update successfully")
         su=("Update Successfully")
      except:
         print("error")
         su=("Error In Update")

      dic={}  
      dic['status']=su 
   
   return render(request,"UpdateStatus.html",dic)



def dele(request):
   return render(request,"DeleteBook.html")

def delbook(request):
   if request.method=="POST":
      try:
         id=request.POST.get('bookid')
         dic={}
         dic["bookid"]=id
         print(dic)

         client=MongoClient("mongodb+srv://nawalkarvaishnavi12:vaishnavi3105@vaishnavicluster.b3hvcgi.mongodb.net/?retryWrites=true&w=majority&appName=VaishnaviCluster")
         db=client['vaishnavidb']
         collection = db['Book']
         collection.delete_one(dic)
         print("delete succesfully")
         msg=("Deleted Succesfully")
      except:
         print("error in code")   
         msg=("Book Not Found")

      dic={}
      dic["status"]=msg

   return render(request,"DeleteStatus.html",dic)      

       